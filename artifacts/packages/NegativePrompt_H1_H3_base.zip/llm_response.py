import os
import re
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, T5Tokenizer, T5ForConditionalGeneration


def get_response_from_llm(
    llm_model,
    queries,
    task,
    few_shot,
    api_num=4,
    temperature=0.0, #greedy, déterministe max 
    do_sample=False
):
    print("=== DEBUG llm_response ===")
    print("llm_model =", llm_model)
    print("temperature =", temperature)
    print("do_sample =", do_sample)
    print("len(queries) =", len(queries))

    model_outputs = []
    device = "cuda" if torch.cuda.is_available() else "cpu"

    print("=== DEBUG llm_response ===")
    print("llm_model =", llm_model)
    print("device =", device)
    print("len(queries) =", len(queries))

    # -------------------------
    # FLAN-T5 / T5
    # -------------------------
    if llm_model.lower() in ["t5", "flan-t5-large", "flan_t5_large"]:
        print("DEBUG branch = FLAN-T5")

        tokenizer = T5Tokenizer.from_pretrained("google/flan-t5-large")
        model = T5ForConditionalGeneration.from_pretrained(
            "google/flan-t5-large",
            device_map="auto" if device == "cuda" else None
        )

        if device == "cpu":
            model = model.to(device)

        for idx, q in enumerate(queries):
            try:
                print(f"\n--- QUERY {idx+1}/{len(queries)} ---")
                print(q)

                inputs = tokenizer(q, return_tensors="pt")
                input_ids = inputs.input_ids.to(device)

                gen_kwargs = {
                    "max_new_tokens": 20,
                    "do_sample": do_sample,
                }

                if do_sample:
                    gen_kwargs["temperature"] = temperature

                outputs = model.generate(input_ids, **gen_kwargs)

                out_text = tokenizer.decode(outputs[0], skip_special_tokens=True).strip()

                print("DEBUG raw output =", out_text)
                model_outputs.append(out_text)

            except Exception as e:
                print("DEBUG exception in FLAN-T5 branch =", repr(e))
                raise

        del model, tokenizer
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

        print("DEBUG returning", len(model_outputs), "outputs")
        return model_outputs

    # -------------------------
    # VICUNA
    # -------------------------
    elif llm_model.lower() == "vicuna":
        print("DEBUG branch = VICUNA")

        model_id = "lmsys/vicuna-7b-v1.5"
        tokenizer = AutoTokenizer.from_pretrained(model_id)
        model = AutoModelForCausalLM.from_pretrained(
            model_id,
            device_map="auto" if device == "cuda" else None,
            load_in_4bit=True if device == "cuda" else False
        )

        if device == "cpu":
            model = model.to(device)

        for idx, q in enumerate(queries):
            try:
                print(f"\n--- QUERY {idx+1}/{len(queries)} ---")
                print(q)

                inputs = tokenizer(q, return_tensors="pt")
                input_ids = inputs.input_ids.to(device)

                gen_kwargs = {
                    "max_new_tokens": 50,
                    "do_sample": do_sample,
                }

                if do_sample:
                    gen_kwargs["temperature"] = temperature

                outputs = model.generate(input_ids, **gen_kwargs)

                out_text = tokenizer.decode(outputs[0], skip_special_tokens=True)

                if out_text.startswith(q):
                    out_text = out_text[len(q):].strip()

                ans = re.search(r"Answer:\s*(.*)", out_text)
                final_text = ans.group(1).strip() if ans else out_text.split('\n')[0].strip()

                print("DEBUG raw output =", out_text)
                print("DEBUG final output =", final_text)

                model_outputs.append(final_text)

            except Exception as e:
                print("DEBUG exception in VICUNA branch =", repr(e))
                raise

        del model, tokenizer
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

        print("DEBUG returning", len(model_outputs), "outputs")
        return model_outputs

    # -------------------------
    # LLAMA2
    # -------------------------
    elif llm_model.lower() == "llama2":
        print("DEBUG branch = LLAMA2")

        model_id = "meta-llama/Llama-2-7b-chat-hf"
        tokenizer = AutoTokenizer.from_pretrained(model_id)
        model = AutoModelForCausalLM.from_pretrained(
            model_id,
            device_map="auto" if device == "cuda" else None,
            load_in_4bit=True if device == "cuda" else False
        )

        if device == "cpu":
            model = model.to(device)

        for idx, q in enumerate(queries):
            try:
                print(f"\n--- QUERY {idx+1}/{len(queries)} ---")
                print(q)

                inputs = tokenizer(q, return_tensors="pt")
                input_ids = inputs.input_ids.to(device)

                outputs = model.generate(
                    input_ids,
                    max_new_tokens=50,
                    temperature=0.7,
                    do_sample=True
                )

                out_text = tokenizer.decode(outputs[0], skip_special_tokens=True)

                if out_text.startswith(q):
                    out_text = out_text[len(q):].strip()

                ans = re.search(r"Answer:\s*(.*)", out_text)
                final_text = ans.group(1).strip() if ans else out_text.split('\n')[0].strip()

                print("DEBUG raw output =", out_text)
                print("DEBUG final output =", final_text)

                model_outputs.append(final_text)

            except Exception as e:
                print("DEBUG exception in LLAMA2 branch =", repr(e))
                raise

        del model, tokenizer
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

        print("DEBUG returning", len(model_outputs), "outputs")
        return model_outputs

    else:
        raise ValueError(
            f"Modèle non reconnu dans llm_response.py : {llm_model}. "
            f"Utilise par exemple 't5', 'flan-t5-large', 'vicuna' ou 'llama2'."
        )